export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyAgsK1Is0QwGwhCQsKAm5nsAcYxcez6vGU',
    authDomain: 'ng-fitness-tracker.firebaseapp.com',
    databaseURL: 'https://ng-fitness-tracker.firebaseio.com',
    projectId: 'ng-fitness-tracker',
    storageBucket: 'ng-fitness-tracker.appspot.com',
    messagingSenderId: '183546960271'
  }
};
