export interface AircraftTypeModel {
  aircraftTypeId: number;
  shortName: string;
  longName: string;
  description: string;
  notes: string;
}
