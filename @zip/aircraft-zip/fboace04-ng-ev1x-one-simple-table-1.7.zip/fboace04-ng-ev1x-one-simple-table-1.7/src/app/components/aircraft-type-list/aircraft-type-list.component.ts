import {Component, OnDestroy, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AircraftTypeModel} from './AircraftType.model';
import {appSettings} from '../../../assets/app-settings.json';
import {Subscription} from 'rxjs';
import {AppConstants} from '../../app-constants';

@Component({
  selector: 'app-aircraft-type-list',
  templateUrl: './aircraft-type-list.component.html',
  styleUrls: ['./aircraft-type-list.component.css']
})
export class AircraftTypeListComponent implements OnInit, OnDestroy {
  title = 'Aircraft Types';
  private readonly BACKEND_URL = appSettings.wsBaseUrl + appSettings.wsAircraftTypeUrl;
  instances: Array<AircraftTypeModel> = [];
  deleteSuccess = false;
  deleteFailure = false;
  getFailure = '';
  private myDate: Date = new Date(); // Just to show that we can
  readonly newRecToken = AppConstants.NEW_REC_TOKEN;

  private subscribers: Array<Subscription> = [];

  constructor(private http: HttpClient) {
    console.log('AircraftTypeListComponent constructor');
  }

  ngOnInit(): void {
    console.log('AircraftTypeListComponent ngOnInit()');
    this.getData1();
  }

  ngOnDestroy(): void {
    for (const subscriber of this.subscribers) {
      subscriber.unsubscribe();
    }
  }

  private getData0(): void {
    console.log('AircraftTypeListComponent getData0()');
    this.http.get<AircraftTypeModel[]>(this.BACKEND_URL)
      .subscribe(responseData => {
        this.instances = responseData;
        console.log('this.instances.length = ' + this.instances.length);
        console.log('this.instances:');
        console.log(this.instances);
      }).unsubscribe();
  }

  private getData1(): void {
    console.log('AircraftTypeListComponent getData1()');
    const subscription: Subscription = this.http.get<AircraftTypeModel[]>(this.BACKEND_URL)
      .subscribe(responseData => {
        this.instances = responseData;
        console.log('this.instances.length = ' + this.instances.length);
        console.log('this.instances:');
        console.log(this.instances);
        subscription.unsubscribe();
      });
  }

  private getData2(): void {
    console.log('AircraftTypeListComponent getData2()');
    this.subscribers.push(this.http.get<AircraftTypeModel[]>(this.BACKEND_URL)
      .subscribe(
        (response: AircraftTypeModel[]): void => {
          this.instances = response;
          console.log('this.instances.length = ' + this.instances.length);
          console.log('this.instances:');
          console.log(this.instances);
        },
        (err: any) => {
          // handle me
        }, () =>  {}
      ));
  }

  private async getData(): Promise<void> {
    console.log('AircraftTypeListComponent getData()');
    try {
      this.instances = await this.http.get<AircraftTypeModel[]>(this.BACKEND_URL).toPromise();
      console.log('this.instances.length = ' + this.instances.length);
      console.log('this.instances:');
      console.log(this.instances);
      if (this.instances.length === 0) {
        this.getFailure = 'No database table records satisfy query criteria.';
      } else {
        this.getFailure = '';
      }
    } catch (err) {
      this.getFailure = 'Unable to get data from webservice.';
      console.error(this.getFailure);
    }
  }

  private getData3(): void {
    console.log('AircraftTypeListComponent getData3()');
    this.http.get<AircraftTypeModel[]>(this.BACKEND_URL).toPromise()
      .then(
        (response: AircraftTypeModel[]): void => {
          this.instances = response;
          console.log('this.instances.length = ' + this.instances.length);
          console.log('this.instances:');
          console.log(this.instances);
        },
        (err: any) => {
          // handle me
        }
      ).catch( () => {
        // handle error
      }
    );
  }
  public async onDelete(aircraftTypeId: number): Promise<void> {
    this.deleteSuccess = false;
    this.deleteFailure = false;
    try{
      const resp = await this.http.delete(this.BACKEND_URL + '/' + aircraftTypeId).toPromise();
      if (resp) {
        console.log('Deleted ' + aircraftTypeId);
        this.deleteSuccess = true;
      } else {
        console.log('Deleted...Promise never came back.' + aircraftTypeId);
      }
    } catch (err) {
      console.error('Error in aircraft-type.component onDelete()');
      console.error(err);
      this.deleteFailure = true;
    }
    await this.getData();
  }
  // Java: private int sumThese (int addend1, int addend2) { return addend1 + addend2; }
  private sumThese(addend1: number, addend2: number): number {
    const methodName = 'sumThese';
    console.log (methodName + ' is adding ' + addend1 + ' and ' + addend2 + '.');
    return addend1 + addend2;
  }

}


