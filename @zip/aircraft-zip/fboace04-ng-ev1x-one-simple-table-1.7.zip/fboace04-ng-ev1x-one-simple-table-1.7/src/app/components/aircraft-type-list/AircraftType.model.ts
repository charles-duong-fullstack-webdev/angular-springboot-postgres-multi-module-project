import {AppConstants} from '../../app-constants';

export class AircraftTypeModel {
  aircraftTypeId = AppConstants._EMPTY_STRING;
  shortName = AppConstants._EMPTY_STRING;
  longName = AppConstants._EMPTY_STRING;
  description = AppConstants._EMPTY_STRING;
  notes = AppConstants._EMPTY_STRING;
  // tslint:disable-next-line:variable-name
  _new = true;
}
