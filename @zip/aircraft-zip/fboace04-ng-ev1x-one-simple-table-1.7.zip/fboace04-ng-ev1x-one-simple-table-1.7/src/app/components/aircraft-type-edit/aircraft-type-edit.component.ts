import {Component, OnDestroy, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {AircraftTypeModel} from '../aircraft-type-list/AircraftType.model';
import {ActivatedRoute, Params} from '@angular/router';
import {appSettings} from '../../../assets/app-settings.json';
import {Subscription} from 'rxjs';
import {AppConstants} from '../../app-constants';

@Component({
  selector: 'app-aircraft-type-edit',
  templateUrl: './aircraft-type-edit.component.html',
  styleUrls: ['./aircraft-type-edit.component.css']
})
export class AircraftTypeEditComponent implements OnInit, OnDestroy {
  title = 'Aircraft Type';
  private readonly BACKEND_URL = appSettings.wsBaseUrl + appSettings.wsAircraftTypeUrl;
  instance = new AircraftTypeModel();
  saveSuccess = false;
  saveFailure = false;
  saveFailureMessage = '';
  getDataFailure = false;
  paramSubscription: Subscription | null = null;

  constructor(private http: HttpClient, private route: ActivatedRoute) {
    console.log('AircraftTypeEditComponent constructor');
  }

  ngOnInit(): void {
    console.log('AircraftTypeEditComponent ngOnInit()');
    this.paramSubscription = this.route.params
      .subscribe(params => {
        console.log('AircraftTypeEditComponent: params', params);
        const idParam = params.aircraftTypeId;
        console.log('idParam = ' + idParam);
        if (idParam === AppConstants.NEW_REC_TOKEN){
          this.instance._new = true;
          this.instance.aircraftTypeId = AppConstants._EMPTY_STRING;
        } else {
          this.instance._new = false;
          this.instance.aircraftTypeId = idParam;
          this.getData();
        }
      });
  }
  ngOnDestroy(): void {
    if (this.paramSubscription) {
      this.paramSubscription.unsubscribe(); // Not necessary in the case of ActivatedRoute
      this.paramSubscription = null;
    }
  }

  private async getData(): Promise<void> {
    console.log('AircraftTypeEditComponent getData()');
    try {
      if (!this.instance._new) {
        this.instance = await this.http.get<AircraftTypeModel>(
          this.BACKEND_URL + '/' + this.instance.aircraftTypeId
        ).toPromise();
        console.log('this.instance:' + JSON.stringify(this.instance, null, 2));
        console.log(this.instance);
      }
    } catch (err) {
      console.error('getData failed! ' + err);
      this.getDataFailure = true;
    }
  }

  public refresh(): void {
    this.getData();
  }

  public async onSave0(): Promise<void> {
    // alert('hi I am saving: ' + JSON.stringify(this.instance, null, 2));
    this.saveFailure = false;
    this.saveSuccess = false;
    try{
      let instanceReturned: any = null;
      if (this.instance._new) {
        console.log('Calling POST');
        instanceReturned = await this.http.post(this.BACKEND_URL, this.instance).toPromise();
      } else {
        console.log('Calling PUT');
        instanceReturned = await this.http.put(this.BACKEND_URL, this.instance).toPromise();
      }
      if (instanceReturned) {
        console.log('resp = ', {instanceReturned});
        console.log('Saved it.');
        this.saveSuccess = true;
        this.instance = instanceReturned;
      }
    } catch (err) {
      console.log('Saved (error).', {err});
      this.saveFailure = true;
    }
  }


  public async onSave(): Promise<void> {
    this.saveFailure = false;
    this.saveSuccess = false;
    try{
      let postPutPromise: Promise<AircraftTypeModel>|null = null;
      if (this.instance._new) {
        console.log('Calling POST');
        postPutPromise = this.http.post<AircraftTypeModel>(this.BACKEND_URL, this.instance).toPromise();
      } else {
        console.log('Calling PUT');
        postPutPromise = this.http.put<AircraftTypeModel>(this.BACKEND_URL, this.instance).toPromise();
      }
      this.instance = await postPutPromise;
      if (this.instance) {
        console.log('this.instance returned: ', this.instance);
        console.log('Saved it.');
        this.saveSuccess = true;
      }
    } catch (err) {
      console.log('Saved (error).', {err});
      this.saveFailureMessage = err.error;
      this.saveFailure = true;
    }
  }

}
