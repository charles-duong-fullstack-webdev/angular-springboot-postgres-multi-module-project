export class AppConstants {
    static readonly PATH_HOME = '';
    static readonly PATH_APP = 'fboace04';
    static readonly PATH_SLASH = '/';
    static readonly PATH_AIRCRAFT_TYPE = 'AircraftType';
    static readonly PARAM_AIRCRAFT_TYPE_ID = ':aircraftTypeId';
    static readonly NEW_REC_TOKEN = '_new';
    static readonly _EMPTY_STRING = '';
}
