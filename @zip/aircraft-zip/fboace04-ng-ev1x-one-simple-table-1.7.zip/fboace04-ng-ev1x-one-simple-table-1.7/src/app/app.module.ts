import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {Routes, Router, RouterModule} from '@angular/router';
import {BrowserModule} from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { AircraftTypeListComponent } from './components/aircraft-type-list/aircraft-type-list.component';
import { AircraftTypeEditComponent } from './components/aircraft-type-edit/aircraft-type-edit.component';
import { HomeComponent } from './components/home/home.component';
import { AppNavbarComponent } from './components/app-navbar/app-navbar.component';
import {AppConstants} from './app-constants';

const appRoutes: Routes = [
  {path: AppConstants.PATH_HOME, component: HomeComponent },
  {path: AppConstants.PATH_APP + AppConstants.PATH_SLASH + AppConstants.PATH_AIRCRAFT_TYPE, component: AircraftTypeListComponent},
  {path: AppConstants.PATH_APP + AppConstants.PATH_SLASH + AppConstants.PATH_AIRCRAFT_TYPE + AppConstants.PATH_SLASH
      + AppConstants.PARAM_AIRCRAFT_TYPE_ID, component: AircraftTypeEditComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AircraftTypeListComponent,
    AircraftTypeEditComponent,
    AppNavbarComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes, { onSameUrlNavigation: 'reload' })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
