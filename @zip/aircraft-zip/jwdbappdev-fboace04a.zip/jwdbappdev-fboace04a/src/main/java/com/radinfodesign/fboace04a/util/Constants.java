package com.radinfodesign.fboace04a.util;

public class Constants {
    public static final String RECORD_NOT_DELETED_MESSAGE = "Sorry, record NOT deleted. No further information is available, but the most common cause is the presence of child records. Or, the record might not exist (already deleted).";
    public static final String RECORD_DELETED = " record deleted.";

}
