package com.radinfodesign.fboace04a;

import java.io.IOException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FBOAce04aApplication {

  public static final String APP_NAME = "FBOAce04a";

    public static void main(String[] args) throws IOException {
        SpringApplication.run(FBOAce04aApplication.class, args);
    }

}
